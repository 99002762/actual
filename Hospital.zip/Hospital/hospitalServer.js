const express = require('express');
const app = express();
const parser = require("body-parser");
const fs = require("fs");
const dir = __dirname;

app.use(parser.urlencoded({ extended: true }));
app.use(parser.json());





 

app.listen(4646, ()=>{
    console.log("Server available at 4646");
})