

const express = require('express');
const app = express();

app.use(express.static('public'));


app.get("/", (req, res) => {
    res.sendFile(__dirname + "/views/Home.html");
})

app.get("/Home.html", (req, res) => {
    res.sendFile(__dirname + "/views/Home.html");
})


 app.get("/AboutUs.html", (req, res) => {
     res.sendFile(__dirname + "/views/AboutUs.html");
 })
app.get("/Appointment.html", (req, res) => {
    res.sendFile(__dirname + "/views/Appointment.html");
})
 app.get("/ContactUs.html", (req, res) => {
     res.sendFile(__dirname + "/views/ContactUs.html");
 })
 app.get("/department.html", (req, res) => {
     res.sendFile(__dirname + "/views/department.html");
 })

app.listen(3333, () => {
    console.log("Client App running at 3333");
})
