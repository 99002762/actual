const express = require('express');
const app = express();
const parser = require("body-parser");
const fs = require("fs");
const dir = __dirname;

app.use(parser.urlencoded({ extended: true }));
app.use(parser.json());
app.use(express.static('public'));

const patients = [];


 function readPatients(){
     const filename = "patients.json";
     const jsonPatients = fs.readFileSync(filename,'utf-8');
    patients = JSON.parse(jsonPatients);
 }



function savePatients(){
    const filename = 'patients.json';
    const jsonData = JSON.stringify(patients);
    fs.writeFileSync(filename,jsonData,'utf-8');
}

 

app.get("/patients", (req, res)=>{
    readPatients();
    res.send(JSON.stringify(patients));
})

app.get("/patients/:name", (req, res)=>{
    const pname = req.params.name;
    if (patients.length == 0) {
        readPatients();
    }
    let foundRec = patients.find((e) => e.patientName == pname);
    if (foundRec == null)
        throw "User not found";
    res.send(JSON.stringify(foundRec))
})


app.put("/patients", (req, res)=>{
    if (patients.length == 0)
        readPatients(); //Fill the array if it is not loaded....
    let body = req.body;
    //console.log(body);
    let flag=0;
    for (let index = 0; index < patients.length; index++) {
        let element = patients[index];
        if (element.patientName == body.patientName) { //find the matching record
            element.patientName = body.patientName;
            element.patientMobile = body.patientMobile;
            element.department = body.department;
            element.date = body.date;
            savePatients();
            res.send("Details updated successfully");
            flag=1;
        }
        
    }
    if(flag==0){
        res.send("Error in updating details");
    }


})


app.post("/patients", (req, res)=>{
    
    let body = req.body;
    if(body.patientName!=""){
       patients.push(body);
        savePatients();
         res.send("Appointment Success");
    }
    else{
        res.send(" Invalid details");
    }
})
///Deleting the Patient appointment.....
app.delete("/patients/:name", (req, res) =>{
    const pname = req.params.name;
    let flag=0;
    if (patients.length == 0) {
        readPatients();
    }
    for (let index = 0; index < patients.length; index++) {
        let element = patients[index];
        if (element.patientName == pname) { //find the matching record
            //console.log(element);
            patients.splice(index,1);
            savePatients();
            res.send("Apointment Cancelled successfully");
            flag=1;
        }
        
    }
    if(flag==0){
        res.send("Error in cancellation");
    }


})


app.listen(4646, ()=>{
    console.log("Server available at 4646");
})